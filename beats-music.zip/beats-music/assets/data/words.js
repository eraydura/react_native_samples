const words = [
  [
    'IN THE GARAGE',
    'ON A BOAT',
    'AT MY COMPUTER',
    'KIND OF A BIG DEAL',
    'IN MY RIDE',
    'AT THE GYM',
    'ON THE SUBWAY',
    'FASHIONABLY LATE',
    'IN THE FUTURE',
  ],
  [
    'INNOVATING',
    'NAPPING',
    'BBQING',
    'WORKING',
    'FINGERPAINTING',
    'HACKING',
    'MAKING BAD CHOICES',
  ],
  [
    'MY COHORT',
    'MY CO-WORKERS',
    'STRANGERS',
    'MY BFF',
    'ROBOTS',
    'YOU',
    'NOBODY'
  ],
  [
    'HIP-HOP',
    'CLASSIC ROCK',
    'ALTERNATIVE',
    'POP',
    'ELECTRONIC',
    'R&B',
    'METAL',
    'CLASSICAL',
    'FOLK',
    'RAP',
  ],
];

export default words
