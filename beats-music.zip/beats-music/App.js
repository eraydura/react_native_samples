import React, { Component } from 'react';
import CompleteApp from './components/_CompleteApp.js'

export default class App extends Component {
  render() {
    return(
      <CompleteApp/>
    )
  }
}


